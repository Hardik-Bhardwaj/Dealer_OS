import { Router } from "express";
import { db } from "@workspace/db";
import { distributorsTable, weeklyTrendsTable, actionMemosTable } from "@workspace/db";
import { eq, and, ilike, sql } from "drizzle-orm";
import {
  ListDistributorsQueryParams,
  GetDistributorTrendParams,
  GetDistributorMemoParams,
} from "@workspace/api-zod";

const router = Router();

router.get("/distributors", async (req, res) => {
  try {
    const parsed = ListDistributorsQueryParams.safeParse(req.query);
    const filters = parsed.success ? parsed.data : {};

    const conditions = [];
    if (filters.state) conditions.push(eq(distributorsTable.state, filters.state));
    if (filters.district) conditions.push(eq(distributorsTable.district, filters.district));
    if (filters.tier) conditions.push(eq(distributorsTable.tier, filters.tier as "Priority" | "Standard" | "Restricted"));
    if (filters.search) conditions.push(ilike(distributorsTable.name, `%${filters.search}%`));

    const rows = conditions.length > 0
      ? await db.select().from(distributorsTable).where(and(...conditions))
      : await db.select().from(distributorsTable);

    const result = rows.map((r) => ({
      id: r.id,
      name: r.name,
      state: r.state,
      district: r.district,
      tier: r.tier,
      healthScore: r.healthScore,
      sellThrough: r.sellThrough,
      inventoryAge: r.inventoryAge,
      paymentDelay: r.paymentDelay,
      returnRate: r.returnRate,
      dealerCoverage: r.dealerCoverage,
      revenueLocked: r.revenueLocked,
      recoverableRevenue: r.recoverableRevenue,
      marketPotential: r.marketPotential,
      weeklyRevenue: r.weeklyRevenue,
    }));

    return res.json(result);
  } catch (err) {
    req.log.error({ err }, "Failed to list distributors");
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/distributors/summary", async (req, res) => {
  try {
    const rows = await db.select().from(distributorsTable);
    if (rows.length === 0) {
      return res.json({
        totalRevenueLocked: 0,
        restrictedCount: 0,
        avgHealthScore: 0,
        recoverableWeeklyRevenue: 0,
        totalDistributors: 0,
        priorityCount: 0,
        standardCount: 0,
        lastUpdated: null,
      });
    }

    const totalRevenueLocked = rows.reduce((acc, r) => acc + r.revenueLocked, 0);
    const restrictedCount = rows.filter((r) => r.tier === "Restricted").length;
    const priorityCount = rows.filter((r) => r.tier === "Priority").length;
    const standardCount = rows.filter((r) => r.tier === "Standard").length;
    const avgHealthScore = rows.reduce((acc, r) => acc + r.healthScore, 0) / rows.length;
    const recoverableWeeklyRevenue = rows
      .filter((r) => r.tier === "Restricted")
      .reduce((acc, r) => acc + r.recoverableRevenue, 0);

    const latest = rows.reduce((acc, r) => {
      if (!acc || (r.updatedAt && acc.updatedAt && r.updatedAt > acc.updatedAt)) return r;
      return acc;
    });

    return res.json({
      totalRevenueLocked: Math.round(totalRevenueLocked * 100) / 100,
      restrictedCount,
      avgHealthScore: Math.round(avgHealthScore * 10) / 10,
      recoverableWeeklyRevenue: Math.round(recoverableWeeklyRevenue * 100) / 100,
      totalDistributors: rows.length,
      priorityCount,
      standardCount,
      lastUpdated: latest.updatedAt?.toISOString() ?? null,
    });
  } catch (err) {
    req.log.error({ err }, "Failed to get summary");
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/distributors/tier-breakdown", async (req, res) => {
  try {
    const rows = await db.select().from(distributorsTable);
    const tiers = ["Priority", "Standard", "Restricted"] as const;

    const breakdown = tiers.map((tier) => {
      const filtered = rows.filter((r) => r.tier === tier);
      return {
        tier,
        revenueLocked: Math.round(filtered.reduce((acc, r) => acc + r.revenueLocked, 0) * 100) / 100,
        count: filtered.length,
        avgHealthScore: filtered.length > 0
          ? Math.round((filtered.reduce((acc, r) => acc + r.healthScore, 0) / filtered.length) * 10) / 10
          : 0,
      };
    });

    return res.json(breakdown);
  } catch (err) {
    req.log.error({ err }, "Failed to get tier breakdown");
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/distributors/:id/trend", async (req, res) => {
  try {
    const parsed = GetDistributorTrendParams.safeParse({ id: Number(req.params.id) });
    if (!parsed.success) return res.status(400).json({ error: "Invalid id" });

    let trends = await db
      .select()
      .from(weeklyTrendsTable)
      .where(eq(weeklyTrendsTable.distributorId, parsed.data.id));

    if (trends.length === 0) {
      const dist = await db.select().from(distributorsTable).where(eq(distributorsTable.id, parsed.data.id));
      if (dist.length === 0) return res.status(404).json({ error: "Distributor not found" });
      const baseScore = dist[0].healthScore;
      const weeks = [];
      for (let i = 11; i >= 0; i--) {
        const d = new Date();
        d.setDate(d.getDate() - i * 7);
        weeks.push({
          week: `W${String(d.getMonth() + 1).padStart(2, "0")}/${String(d.getDate()).padStart(2, "0")}`,
          score: Math.max(0, Math.min(100, baseScore + (Math.random() - 0.5) * 20)),
        });
      }
      return res.json(weeks);
    }

    return res.json(trends.map((t) => ({ week: t.week, score: t.score })));
  } catch (err) {
    req.log.error({ err }, "Failed to get trend");
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/distributors/:id/memo", async (req, res) => {
  try {
    const parsed = GetDistributorMemoParams.safeParse({ id: Number(req.params.id) });
    if (!parsed.success) return res.status(400).json({ error: "Invalid id" });

    const dist = await db.select().from(distributorsTable).where(eq(distributorsTable.id, parsed.data.id));
    if (dist.length === 0) return res.status(404).json({ error: "Distributor not found" });

    const d = dist[0];
    const memos = await db.select().from(actionMemosTable).where(eq(actionMemosTable.distributorId, parsed.data.id));

    if (memos.length > 0) {
      const m = memos[0];
      return res.json({
        distributorId: d.id,
        distributorName: d.name,
        memo: m.memo,
        keyIssues: JSON.parse(m.keyIssues),
        recommendedActions: JSON.parse(m.recommendedActions),
        estimatedRecovery: m.estimatedRecovery,
        urgency: m.urgency,
      });
    }

    const issues: string[] = [];
    const actions: string[] = [];
    if (d.paymentDelay > 45) issues.push(`Payment delay of ${d.paymentDelay.toFixed(0)} days (threshold: 30 days)`);
    if (d.inventoryAge > 60) issues.push(`Inventory age at ${d.inventoryAge.toFixed(0)} days — slow-moving stock`);
    if (d.sellThrough < 40) issues.push(`Sell-through rate critically low at ${d.sellThrough.toFixed(1)}%`);
    if (d.returnRate > 15) issues.push(`Return rate at ${d.returnRate.toFixed(1)}% — quality or demand mismatch`);
    if (d.dealerCoverage < 50) issues.push(`Dealer coverage at ${d.dealerCoverage.toFixed(1)}% — expansion needed`);
    if (issues.length === 0) issues.push("Multiple compounding performance factors below threshold");

    if (d.paymentDelay > 45) actions.push("Issue 15-day payment ultimatum with settlement discount offer");
    if (d.inventoryAge > 60) actions.push("Initiate inventory rotation plan — return or liquidate aged stock");
    if (d.sellThrough < 40) actions.push("Deploy field sales team for 2-week demand generation push");
    if (d.returnRate > 15) actions.push("Conduct quality audit and review demand forecasting accuracy");
    if (d.dealerCoverage < 50) actions.push("Assign dedicated territory manager for dealer expansion");
    if (actions.length === 0) actions.push("Immediate account review meeting with regional sales head");

    const urgency = d.healthScore < 30 ? "High" : d.healthScore < 50 ? "Medium" : "Low";
    const estimatedRecovery = d.recoverableRevenue;

    return res.json({
      distributorId: d.id,
      distributorName: d.name,
      memo: `${d.name} (${d.district}, ${d.state}) is classified as RESTRICTED with a health score of ${d.healthScore.toFixed(1)}/100. Revenue of ₹${d.revenueLocked.toFixed(2)} Cr is currently locked at this account. Immediate intervention is required to recover an estimated ₹${estimatedRecovery.toFixed(2)} Cr weekly. The account has been deteriorating over the past 12 weeks with key metrics falling below acceptable thresholds.`,
      keyIssues: issues,
      recommendedActions: actions,
      estimatedRecovery,
      urgency,
    });
  } catch (err) {
    req.log.error({ err }, "Failed to get memo");
    return res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
