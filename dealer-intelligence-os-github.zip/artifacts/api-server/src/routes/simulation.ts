import { Router } from "express";
import { db } from "@workspace/db";
import { distributorsTable, insightsSnapshotTable } from "@workspace/db";

const router = Router();

const INDIAN_STATES = [
  "Maharashtra", "Uttar Pradesh", "Karnataka", "Tamil Nadu",
  "West Bengal", "Gujarat", "Rajasthan", "Delhi", "Madhya Pradesh",
  "Andhra Pradesh", "Bihar", "Telangana",
];

const DISTRICTS: Record<string, string[]> = {
  Maharashtra: ["Mumbai", "Pune", "Nagpur", "Nashik", "Aurangabad"],
  "Uttar Pradesh": ["Lucknow", "Kanpur", "Agra", "Varanasi", "Meerut"],
  Karnataka: ["Bengaluru", "Mysuru", "Hubballi", "Mangaluru", "Belagavi"],
  "Tamil Nadu": ["Chennai", "Coimbatore", "Madurai", "Salem", "Trichy"],
  "West Bengal": ["Kolkata", "Asansol", "Siliguri", "Howrah", "Durgapur"],
  Gujarat: ["Ahmedabad", "Surat", "Vadodara", "Rajkot", "Gandhinagar"],
  Rajasthan: ["Jaipur", "Jodhpur", "Udaipur", "Kota", "Ajmer"],
  Delhi: ["New Delhi", "North Delhi", "South Delhi", "East Delhi", "West Delhi"],
  "Madhya Pradesh": ["Bhopal", "Indore", "Jabalpur", "Gwalior", "Ujjain"],
  "Andhra Pradesh": ["Visakhapatnam", "Vijayawada", "Guntur", "Tirupati", "Kurnool"],
  Bihar: ["Patna", "Gaya", "Muzaffarpur", "Bhagalpur", "Darbhanga"],
  Telangana: ["Hyderabad", "Warangal", "Nizamabad", "Karimnagar", "Khammam"],
};

function rand(min: number, max: number) {
  return Math.random() * (max - min) + min;
}

function computeHealthScore(params: {
  sellThrough: number;
  inventoryAge: number;
  paymentDelay: number;
  returnRate: number;
  dealerCoverage: number;
}): number {
  const weights = { sellThrough: 0.3, inventoryAge: 0.2, paymentDelay: 0.25, returnRate: 0.15, dealerCoverage: 0.1 };
  const stScore = Math.min(100, params.sellThrough * 100 / 80);
  const iaScore = Math.max(0, 100 - (params.inventoryAge / 90) * 100);
  const pdScore = Math.max(0, 100 - (params.paymentDelay / 60) * 100);
  const rrScore = Math.max(0, 100 - (params.returnRate / 20) * 100);
  const dcScore = Math.min(100, params.dealerCoverage);
  return (
    stScore * weights.sellThrough +
    iaScore * weights.inventoryAge +
    pdScore * weights.paymentDelay +
    rrScore * weights.returnRate +
    dcScore * weights.dealerCoverage
  );
}

function assignTier(score: number): "Priority" | "Standard" | "Restricted" {
  if (score >= 70) return "Priority";
  if (score >= 40) return "Standard";
  return "Restricted";
}

router.post("/simulate", async (req, res) => {
  try {
    const count = 400 + Math.floor(Math.random() * 20);
    const distributors = [];

    for (let i = 0; i < count; i++) {
      const state = INDIAN_STATES[Math.floor(Math.random() * INDIAN_STATES.length)];
      const districts = DISTRICTS[state] || ["Central"];
      const district = districts[Math.floor(Math.random() * districts.length)];

      const tierRoll = Math.random();
      let sellThrough: number, inventoryAge: number, paymentDelay: number, returnRate: number, dealerCoverage: number;

      if (tierRoll < 0.35) {
        sellThrough = rand(65, 95);
        inventoryAge = rand(15, 45);
        paymentDelay = rand(0, 25);
        returnRate = rand(1, 8);
        dealerCoverage = rand(70, 100);
      } else if (tierRoll < 0.75) {
        sellThrough = rand(35, 70);
        inventoryAge = rand(40, 75);
        paymentDelay = rand(20, 50);
        returnRate = rand(6, 16);
        dealerCoverage = rand(40, 75);
      } else {
        sellThrough = rand(10, 40);
        inventoryAge = rand(60, 120);
        paymentDelay = rand(40, 90);
        returnRate = rand(12, 30);
        dealerCoverage = rand(10, 45);
      }

      const healthScore = computeHealthScore({ sellThrough, inventoryAge, paymentDelay, returnRate, dealerCoverage });
      const tier = assignTier(healthScore);
      const marketPotential = rand(20, 100);
      const revenueLocked = rand(0.5, 12) * (tier === "Restricted" ? 2.5 : tier === "Standard" ? 1.5 : 0.8);
      const recoverableRevenue = tier === "Restricted" ? revenueLocked * rand(0.3, 0.7) : 0;
      const weeklyRevenue = rand(0.1, 3);

      distributors.push({
        name: `Distributor ${state.slice(0, 3).toUpperCase()}-${String(i + 1).padStart(3, "0")}`,
        state,
        district,
        tier,
        healthScore: Math.round(healthScore * 10) / 10,
        sellThrough: Math.round(sellThrough * 10) / 10,
        inventoryAge: Math.round(inventoryAge * 10) / 10,
        paymentDelay: Math.round(paymentDelay * 10) / 10,
        returnRate: Math.round(returnRate * 10) / 10,
        dealerCoverage: Math.round(dealerCoverage * 10) / 10,
        revenueLocked: Math.round(revenueLocked * 100) / 100,
        recoverableRevenue: Math.round(recoverableRevenue * 100) / 100,
        marketPotential: Math.round(marketPotential * 10) / 10,
        weeklyRevenue: Math.round(weeklyRevenue * 100) / 100,
      });
    }

    await db.delete(distributorsTable);
    await db.insert(distributorsTable).values(distributors);

    const restrictedCount = distributors.filter((d) => d.tier === "Restricted").length;
    const avgHealthScore = distributors.reduce((acc, d) => acc + d.healthScore, 0) / distributors.length;
    const totalRevenueLocked = distributors.reduce((acc, d) => acc + d.revenueLocked, 0);
    const recoverableWeeklyRevenue = distributors
      .filter((d) => d.tier === "Restricted")
      .reduce((acc, d) => acc + d.recoverableRevenue, 0);

    await db.delete(insightsSnapshotTable);
    await db.insert(insightsSnapshotTable).values({
      totalRevenueLocked: Math.round(totalRevenueLocked * 100) / 100,
      restrictedCount,
      avgHealthScore: Math.round(avgHealthScore * 10) / 10,
      recoverableWeeklyRevenue: Math.round(recoverableWeeklyRevenue * 100) / 100,
    });

    res.json({
      success: true,
      distributorsGenerated: count,
      message: `Simulation complete. Generated ${count} distributor records across 12 states.`,
    });
  } catch (err) {
    req.log.error({ err }, "Simulation failed");
    res.status(500).json({ error: "Simulation failed" });
  }
});

export default router;
