import { Router } from "express";
import { db } from "@workspace/db";
import { distributorsTable } from "@workspace/db";
import { sql } from "drizzle-orm";

const router = Router();

router.get("/territories", async (req, res) => {
  try {
    const rows = await db.select().from(distributorsTable);

    const grouped = new Map<string, typeof rows>();
    for (const r of rows) {
      const key = `${r.state}|${r.district}`;
      if (!grouped.has(key)) grouped.set(key, []);
      grouped.get(key)!.push(r);
    }

    let id = 1;
    const territories = [];
    for (const [key, dists] of grouped.entries()) {
      const [state, district] = key.split("|");
      const avgHealth = dists.reduce((a, d) => a + d.healthScore, 0) / dists.length;
      const avgMarket = dists.reduce((a, d) => a + d.marketPotential, 0) / dists.length;
      const totalRevLocked = dists.reduce((a, d) => a + d.revenueLocked, 0);

      const tierCounts = { Priority: 0, Standard: 0, Restricted: 0 };
      for (const d of dists) tierCounts[d.tier]++;
      const dominantTier = (Object.entries(tierCounts).sort((a, b) => b[1] - a[1])[0][0]) as "Priority" | "Standard" | "Restricted";

      territories.push({
        id: id++,
        state,
        district,
        healthScore: Math.round(avgHealth * 10) / 10,
        marketPotential: Math.round(avgMarket * 10) / 10,
        distributorCount: dists.length,
        revenueLocked: Math.round(totalRevLocked * 100) / 100,
        tier: dominantTier,
      });
    }

    res.json(territories);
  } catch (err) {
    req.log.error({ err }, "Failed to list territories");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
