import { Router, type IRouter } from "express";
import healthRouter from "./health";
import distributorsRouter from "./distributors";
import territoriesRouter from "./territories";
import insightsRouter from "./insights";
import simulationRouter from "./simulation";

const router: IRouter = Router();

router.use(healthRouter);
router.use(distributorsRouter);
router.use(territoriesRouter);
router.use(insightsRouter);
router.use(simulationRouter);

export default router;
