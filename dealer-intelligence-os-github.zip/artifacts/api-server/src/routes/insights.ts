import { Router } from "express";
import { db } from "@workspace/db";
import { distributorsTable, insightsSnapshotTable } from "@workspace/db";
import { PushInsightsBody } from "@workspace/api-zod";

const router = Router();

router.post("/insights", async (req, res) => {
  try {
    const parsed = PushInsightsBody.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: "Invalid payload", details: parsed.error.issues });
    }

    const { summary, distributors } = parsed.data;

    await db.delete(distributorsTable);

    if (distributors && distributors.length > 0) {
      const rows = distributors.map((d) => ({
        name: d.name,
        state: d.state,
        district: d.district,
        tier: d.tier as "Priority" | "Standard" | "Restricted",
        healthScore: d.healthScore,
        sellThrough: d.sellThrough,
        inventoryAge: d.inventoryAge,
        paymentDelay: d.paymentDelay,
        returnRate: d.returnRate,
        dealerCoverage: d.dealerCoverage,
        revenueLocked: d.revenueLocked,
        recoverableRevenue: d.recoverableRevenue,
        marketPotential: d.marketPotential,
        weeklyRevenue: d.weeklyRevenue,
      }));
      await db.insert(distributorsTable).values(rows);
    }

    await db.delete(insightsSnapshotTable);
    await db.insert(insightsSnapshotTable).values({
      totalRevenueLocked: summary.totalRevenueLocked,
      restrictedCount: summary.restrictedCount,
      avgHealthScore: summary.avgHealthScore,
      recoverableWeeklyRevenue: summary.recoverableWeeklyRevenue,
    });

    return res.json({
      success: true,
      message: `Insights ingested successfully`,
      distributorsInserted: distributors?.length ?? 0,
    });
  } catch (err) {
    req.log.error({ err }, "Failed to push insights");
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/insights", async (req, res) => {
  try {
    const snapshots = await db.select().from(insightsSnapshotTable).limit(1);
    if (snapshots.length === 0) {
      return res.json({ hasData: false });
    }
    const s = snapshots[0];
    return res.json({
      hasData: true,
      lastUpdated: s.updatedAt?.toISOString() ?? null,
      summary: {
        totalRevenueLocked: s.totalRevenueLocked,
        restrictedCount: s.restrictedCount,
        avgHealthScore: s.avgHealthScore,
        recoverableWeeklyRevenue: s.recoverableWeeklyRevenue,
        totalDistributors: 0,
        priorityCount: 0,
        standardCount: 0,
      },
    });
  } catch (err) {
    req.log.error({ err }, "Failed to get insights");
    return res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
