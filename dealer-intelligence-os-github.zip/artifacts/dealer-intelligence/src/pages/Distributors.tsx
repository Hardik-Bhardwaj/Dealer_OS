import React, { useState } from "react";
import { Layout } from "@/components/Layout";
import {
  useListDistributors,
  useGetDistributorTrend,
  getListDistributorsQueryKey,
  getGetDistributorTrendQueryKey,
  type ListDistributorsParams,
} from "@workspace/api-client-react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Search, TrendingUp, TrendingDown, Minus } from "lucide-react";

const TIER_COLORS: Record<string, string> = {
  Priority: "#10b981",
  Standard: "#f59e0b",
  Restricted: "#E8001D",
};

const STATES = [
  "Maharashtra", "Uttar Pradesh", "Karnataka", "Tamil Nadu",
  "West Bengal", "Gujarat", "Rajasthan", "Delhi",
  "Madhya Pradesh", "Andhra Pradesh", "Bihar", "Telangana",
];

function HealthBar({ score }: { score: number }) {
  const color = score >= 70 ? "#10b981" : score >= 40 ? "#f59e0b" : "#E8001D";
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 h-1.5 bg-white/10 rounded-full overflow-hidden min-w-[60px]">
        <div className="h-full rounded-full transition-all" style={{ width: `${score}%`, background: color }} />
      </div>
      <span className="text-xs font-mono w-8 text-right" style={{ color }}>{score.toFixed(0)}</span>
    </div>
  );
}

function TierBadge({ tier }: { tier: string }) {
  const color = TIER_COLORS[tier] || "#888";
  return (
    <span
      className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-mono font-bold tracking-wider"
      style={{ background: color + "22", color, border: `1px solid ${color}44` }}
    >
      {tier.toUpperCase()}
    </span>
  );
}

function TrendChart({ distributorId }: { distributorId: number }) {
  const { data: trend, isLoading } = useGetDistributorTrend(distributorId, {
    query: { queryKey: getGetDistributorTrendQueryKey(distributorId), enabled: !!distributorId },
  });

  if (isLoading) return <Skeleton className="h-40 w-full" />;
  if (!trend || trend.length === 0) return <div className="text-muted-foreground text-xs font-mono py-10 text-center">NO TREND DATA</div>;

  const first = trend[0]?.score ?? 0;
  const last = trend[trend.length - 1]?.score ?? 0;
  const delta = last - first;
  const lineColor = delta >= 0 ? "#10b981" : "#E8001D";

  return (
    <div>
      <div className="flex items-center gap-2 mb-3">
        <span className="text-xs font-mono text-muted-foreground">12-WEEK SCORE TREND</span>
        <span className="flex items-center gap-0.5 text-xs font-mono" style={{ color: lineColor }}>
          {delta >= 2 ? <TrendingUp className="w-3 h-3" /> : delta <= -2 ? <TrendingDown className="w-3 h-3" /> : <Minus className="w-3 h-3" />}
          {delta >= 0 ? "+" : ""}{delta.toFixed(1)}
        </span>
      </div>
      <ResponsiveContainer width="100%" height={140}>
        <LineChart data={trend} margin={{ top: 5, right: 5, left: -20, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
          <XAxis dataKey="week" tick={{ fill: "#555", fontSize: 9, fontFamily: "monospace" }} interval="preserveStartEnd" />
          <YAxis domain={[0, 100]} tick={{ fill: "#555", fontSize: 9, fontFamily: "monospace" }} />
          <Tooltip
            contentStyle={{ background: "#0f0f15", border: "1px solid #222", borderRadius: 4, fontSize: 11, fontFamily: "monospace" }}
            formatter={(v: any) => [v.toFixed(1), "Score"]}
          />
          <Line type="monotone" dataKey="score" stroke={lineColor} strokeWidth={2} dot={false} activeDot={{ r: 4, fill: lineColor }} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

export default function Distributors() {
  const [search, setSearch] = useState("");
  const [tier, setTier] = useState<string>("all");
  const [state, setState] = useState<string>("all");
  const [selectedId, setSelectedId] = useState<number | null>(null);

  const params: ListDistributorsParams = {
    ...(search ? { search } : {}),
    ...(tier !== "all" ? { tier: tier as ListDistributorsParams["tier"] } : {}),
    ...(state !== "all" ? { state } : {}),
  };

  const { data: distributors, isLoading } = useListDistributors(
    Object.keys(params).length > 0 ? params : undefined,
    { query: { queryKey: getListDistributorsQueryKey(Object.keys(params).length > 0 ? params : undefined) } }
  );

  const sorted = [...(distributors || [])].sort((a, b) => a.healthScore - b.healthScore);
  const selected = sorted.find((d) => d.id === selectedId);

  return (
    <Layout>
      <div className="p-8 max-w-[1600px] mx-auto">
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
          <h1 className="text-3xl font-bold tracking-tight mb-1">DISTRIBUTOR DEEP-DIVE</h1>
          <p className="text-muted-foreground text-sm mb-6">
            {isLoading ? "Loading..." : `${sorted.length} distributors · click a row to view trend`}
          </p>
        </motion.div>

        {/* Filters */}
        <div className="flex flex-wrap gap-3 mb-6">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search distributor..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9 bg-card border-border font-mono text-sm h-9"
            />
          </div>
          <Select value={tier} onValueChange={setTier}>
            <SelectTrigger className="w-40 bg-card border-border font-mono text-sm h-9">
              <SelectValue placeholder="All Tiers" />
            </SelectTrigger>
            <SelectContent className="bg-card border-border font-mono">
              <SelectItem value="all">All Tiers</SelectItem>
              <SelectItem value="Priority">Priority</SelectItem>
              <SelectItem value="Standard">Standard</SelectItem>
              <SelectItem value="Restricted">Restricted</SelectItem>
            </SelectContent>
          </Select>
          <Select value={state} onValueChange={setState}>
            <SelectTrigger className="w-48 bg-card border-border font-mono text-sm h-9">
              <SelectValue placeholder="All States" />
            </SelectTrigger>
            <SelectContent className="bg-card border-border font-mono">
              <SelectItem value="all">All States</SelectItem>
              {STATES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
          {/* Table */}
          <div className="xl:col-span-2">
            <Card className="border-border bg-card/80 overflow-hidden">
              {/* Table Header */}
              <div className="grid grid-cols-[2fr_1fr_1fr_1.5fr_1fr] gap-2 px-4 py-2.5 border-b border-border bg-white/3 text-[10px] font-mono text-muted-foreground uppercase tracking-widest">
                <span>Distributor</span>
                <span>Tier</span>
                <span className="text-right">Rev. Locked</span>
                <span>Health</span>
                <span className="text-right">Sell-thru</span>
              </div>

              {isLoading ? (
                <div className="divide-y divide-border">
                  {Array.from({ length: 10 }).map((_, i) => (
                    <div key={i} className="px-4 py-3">
                      <Skeleton className="h-4 w-full" />
                    </div>
                  ))}
                </div>
              ) : (
                <div className="divide-y divide-border/50 max-h-[60vh] overflow-y-auto">
                  <AnimatePresence>
                    {sorted.slice(0, 100).map((d, i) => (
                      <motion.div
                        key={d.id}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: Math.min(i * 0.01, 0.3) }}
                        className={`grid grid-cols-[2fr_1fr_1fr_1.5fr_1fr] gap-2 px-4 py-3 cursor-pointer transition-colors ${
                          selectedId === d.id
                            ? "bg-primary/10 border-l-2 border-l-primary"
                            : "hover:bg-white/3 border-l-2 border-l-transparent"
                        }`}
                        onClick={() => setSelectedId(selectedId === d.id ? null : d.id)}
                        style={{ borderLeftColor: selectedId === d.id ? TIER_COLORS[d.tier] : "transparent" }}
                      >
                        <div>
                          <div className="text-xs font-medium text-white truncate">{d.name}</div>
                          <div className="text-[10px] text-muted-foreground font-mono">{d.district}, {d.state}</div>
                        </div>
                        <div className="flex items-center"><TierBadge tier={d.tier} /></div>
                        <div className="text-right">
                          <div className="text-xs font-mono text-white">₹{d.revenueLocked.toFixed(1)}</div>
                          <div className="text-[10px] text-muted-foreground">Cr</div>
                        </div>
                        <div className="flex items-center"><HealthBar score={d.healthScore} /></div>
                        <div className="text-right text-xs font-mono text-muted-foreground">{d.sellThrough.toFixed(1)}%</div>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                  {sorted.length === 0 && (
                    <div className="py-16 text-center text-muted-foreground font-mono text-sm">NO DISTRIBUTORS FOUND</div>
                  )}
                </div>
              )}
            </Card>
          </div>

          {/* Detail Panel */}
          <div>
            <AnimatePresence mode="wait">
              {selected ? (
                <motion.div
                  key={selected.id}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  transition={{ duration: 0.25 }}
                >
                  <Card className="border-border bg-card/80 p-5">
                    <div className="mb-4">
                      <div className="flex items-start justify-between mb-1">
                        <h3 className="text-sm font-bold text-white">{selected.name}</h3>
                        <TierBadge tier={selected.tier} />
                      </div>
                      <p className="text-xs text-muted-foreground font-mono">{selected.district}, {selected.state}</p>
                    </div>

                    <div className="grid grid-cols-2 gap-3 mb-5">
                      {[
                        { label: "HEALTH", value: `${selected.healthScore.toFixed(1)}`, suffix: "/100" },
                        { label: "REV LOCKED", value: `₹${selected.revenueLocked.toFixed(2)}`, suffix: "Cr" },
                        { label: "SELL-THRU", value: `${selected.sellThrough.toFixed(1)}`, suffix: "%" },
                        { label: "INV AGE", value: `${selected.inventoryAge.toFixed(0)}`, suffix: "d" },
                        { label: "PAY DELAY", value: `${selected.paymentDelay.toFixed(0)}`, suffix: "d" },
                        { label: "RETURN", value: `${selected.returnRate.toFixed(1)}`, suffix: "%" },
                        { label: "COVERAGE", value: `${selected.dealerCoverage.toFixed(1)}`, suffix: "%" },
                        { label: "MKT POT.", value: `${selected.marketPotential.toFixed(0)}`, suffix: "/100" },
                      ].map(({ label, value, suffix }) => (
                        <div key={label} className="bg-white/3 rounded p-2 border border-border/50">
                          <div className="text-[9px] font-mono text-muted-foreground mb-0.5">{label}</div>
                          <div className="text-sm font-mono font-bold text-white">{value}<span className="text-[10px] text-muted-foreground ml-0.5">{suffix}</span></div>
                        </div>
                      ))}
                    </div>

                    <TrendChart distributorId={selected.id} />
                  </Card>
                </motion.div>
              ) : (
                <motion.div
                  key="empty"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                >
                  <Card className="border-border bg-card/40 p-8 text-center border-dashed">
                    <div className="text-muted-foreground font-mono text-xs">SELECT A DISTRIBUTOR</div>
                    <div className="text-muted-foreground/50 font-mono text-[10px] mt-1">to view score trend & KPIs</div>
                  </Card>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </Layout>
  );
}
