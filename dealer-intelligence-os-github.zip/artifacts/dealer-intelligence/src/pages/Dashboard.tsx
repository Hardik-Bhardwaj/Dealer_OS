import React, { useEffect, useRef, useState } from "react";
import { Layout } from "@/components/Layout";
import {
  useGetLatestInsights,
  useGetDistributorSummary,
  useGetTierBreakdown,
  getGetLatestInsightsQueryKey,
  getGetDistributorSummaryQueryKey,
  getGetTierBreakdownQueryKey,
} from "@workspace/api-client-react";
import { Card } from "@/components/ui/card";
import { motion } from "framer-motion";
import { AlertCircle, IndianRupee, Activity, Users, Terminal, Network, Target, Zap, Copy, CheckCheck } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Link } from "wouter";

const TIER_COLORS: Record<string, string> = {
  Priority: "#10b981",
  Standard: "#f59e0b",
  Restricted: "#E8001D",
};

function useCountUp(target: number, duration = 1500) {
  const [count, setCount] = useState(0);
  useEffect(() => {
    if (!target) return;
    let start: number | null = null;
    const step = (timestamp: number) => {
      if (!start) start = timestamp;
      const progress = Math.min((timestamp - start) / duration, 1);
      const ease = 1 - Math.pow(1 - progress, 3);
      setCount(target * ease);
      if (progress < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }, [target, duration]);
  return count;
}

function AnimatedKPI({
  label, value, suffix, prefix = "", color, icon: Icon, glow,
}: {
  label: string; value: number; suffix?: string; prefix?: string; color?: string; icon: React.ElementType; glow?: boolean;
}) {
  const animated = useCountUp(value);
  return (
    <Card
      className="p-6 border-border bg-card/80 backdrop-blur relative overflow-hidden"
      style={glow ? { borderColor: color + "50", background: color + "0a" } : {}}
    >
      {glow && (
        <div
          className="absolute top-0 right-0 w-40 h-40 rounded-full blur-3xl -mr-16 -mt-16 pointer-events-none"
          style={{ background: color + "18" }}
        />
      )}
      <div className="flex items-center gap-2 mb-4 relative z-10" style={{ color: glow ? color : undefined }}>
        <Icon className="w-4 h-4" style={{ color: glow ? color : "inherit" }} />
        <span className="text-xs font-mono uppercase tracking-wider text-muted-foreground">{label}</span>
      </div>
      <div className="relative z-10 font-mono tracking-tighter" style={{ color: glow ? color : "white" }}>
        <span className="text-4xl font-bold">
          {prefix}{animated.toFixed(value % 1 === 0 ? 0 : 2)}
        </span>
        {suffix && <span className="text-xl text-muted-foreground ml-1">{suffix}</span>}
      </div>
    </Card>
  );
}

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      onClick={() => { navigator.clipboard.writeText(text); setCopied(true); setTimeout(() => setCopied(false), 2000); }}
      className="flex items-center gap-1.5 text-[10px] font-mono text-muted-foreground hover:text-white transition-colors"
    >
      {copied ? <CheckCheck className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
      {copied ? "COPIED" : "COPY"}
    </button>
  );
}

const EXAMPLE_PAYLOAD = `import requests

url = "https://your-replit-app.replit.app/api/insights"

payload = {
  "summary": {
    "totalRevenueLocked": 1256.40,
    "restrictedCount": 42,
    "avgHealthScore": 68.4,
    "recoverableWeeklyRevenue": 14.2
  },
  "distributors": [
    {
      "id": 1,
      "name": "Distributor MH-001",
      "state": "Maharashtra",
      "district": "Mumbai",
      "tier": "Restricted",
      "healthScore": 28.5,
      "sellThrough": 22.3,
      "inventoryAge": 85.0,
      "paymentDelay": 62.0,
      "returnRate": 19.5,
      "dealerCoverage": 31.0,
      "revenueLocked": 8.4,
      "recoverableRevenue": 3.2,
      "marketPotential": 76.0,
      "weeklyRevenue": 0.9
    }
    # ... add all 400+ distributors
  ]
}

response = requests.post(url, json=payload)
print(response.json())`;

export default function Dashboard() {
  const { data: insights, isLoading: isInsightsLoading } = useGetLatestInsights({
    query: { queryKey: getGetLatestInsightsQueryKey() },
  });

  const { data: summary, isLoading: isSummaryLoading } = useGetDistributorSummary({
    query: { queryKey: getGetDistributorSummaryQueryKey(), enabled: insights?.hasData === true },
  });

  const { data: tiers } = useGetTierBreakdown({
    query: { queryKey: getGetTierBreakdownQueryKey(), enabled: insights?.hasData === true },
  });

  const container = {
    hidden: { opacity: 0 },
    show: { opacity: 1, transition: { staggerChildren: 0.1 } },
  };
  const item = { hidden: { opacity: 0, y: 20 }, show: { opacity: 1, y: 0 } };

  if (isInsightsLoading) {
    return (
      <Layout>
        <div className="p-8 flex items-center justify-center h-full">
          <div className="flex flex-col items-center gap-4">
            <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin" />
            <div className="text-muted-foreground font-mono text-sm">INITIALIZING COMMAND CENTER...</div>
          </div>
        </div>
      </Layout>
    );
  }

  if (!insights?.hasData) {
    return (
      <Layout>
        <div className="p-8 max-w-4xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold tracking-tight mb-1">EXECUTIVE COMMAND CENTER</h1>
            <p className="text-muted-foreground text-sm">Revenue Intelligence</p>
          </div>

          <Alert className="border-primary/40 bg-primary/8 mb-6">
            <AlertCircle className="h-5 w-5 !text-primary" />
            <AlertTitle className="text-base font-bold font-mono">AWAITING TELEMETRY DATA</AlertTitle>
            <AlertDescription className="mt-1 text-muted-foreground text-sm">
              No data yet. Run the Colab notebook and push results, or click "Run Simulation" in the sidebar to load 400+ synthetic distributor records.
            </AlertDescription>
          </Alert>

          <Card className="border-border bg-card/70 p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Terminal className="w-4 h-4 text-muted-foreground" />
                <h3 className="font-mono text-xs text-muted-foreground uppercase tracking-widest">Colab Integration — Push Your Model Results</h3>
              </div>
              <CopyButton text={EXAMPLE_PAYLOAD} />
            </div>
            <div className="bg-black/60 p-4 rounded border border-border/60 font-mono text-xs text-muted-foreground overflow-x-auto leading-relaxed">
              <pre className="whitespace-pre">{EXAMPLE_PAYLOAD}</pre>
            </div>
            <div className="mt-4 flex items-start gap-2 text-xs text-muted-foreground/70">
              <span className="text-primary font-bold font-mono mt-0.5">NOTE</span>
              <span>Replace the URL with your Replit app's domain. The <code className="bg-white/5 px-1 rounded">tier</code> field must be "Priority", "Standard", or "Restricted". All numeric fields are required.</span>
            </div>
          </Card>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="p-8 pb-16 max-w-[1600px] mx-auto">
        {/* Header */}
        <div className="flex justify-between items-end mb-8">
          <div>
            <h1 className="text-3xl font-bold tracking-tight mb-1">EXECUTIVE COMMAND CENTER</h1>
            <p className="text-muted-foreground text-sm">Revenue Intelligence Dashboard</p>
          </div>
          <div className="text-right">
            <div className="text-[10px] font-mono text-muted-foreground mb-1 uppercase tracking-widest">System Status: Online</div>
            {summary?.lastUpdated && (
              <div className="text-xs font-mono text-primary/80 border border-primary/25 bg-primary/8 px-3 py-1.5 rounded flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-primary animate-pulse flex-shrink-0" />
                LAST SYNC: {new Date(summary.lastUpdated).toLocaleString("en-IN", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" })}
              </div>
            )}
          </div>
        </div>

        {/* KPI Cards */}
        {summary && (
          <motion.div
            variants={container}
            initial="hidden"
            animate="show"
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8"
          >
            <motion.div variants={item}>
              <AnimatedKPI label="Total Revenue Locked" value={summary.totalRevenueLocked} prefix="₹" suffix="Cr" icon={IndianRupee} />
            </motion.div>
            <motion.div variants={item}>
              <AnimatedKPI label="Restricted Dealers" value={summary.restrictedCount} icon={AlertCircle} color="#E8001D" glow />
            </motion.div>
            <motion.div variants={item}>
              <AnimatedKPI label="Avg Network Health" value={summary.avgHealthScore} suffix="/ 100" icon={Activity} />
            </motion.div>
            <motion.div variants={item}>
              <AnimatedKPI label="Recoverable Weekly" value={summary.recoverableWeeklyRevenue} prefix="₹" suffix="Cr" icon={IndianRupee} color="#10b981" glow />
            </motion.div>
          </motion.div>
        )}

        {/* Network Stats Row */}
        {summary && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="grid grid-cols-3 gap-4 mb-8"
          >
            {[
              { label: "Priority Dealers", value: summary.priorityCount, color: "#10b981", pct: (summary.priorityCount / summary.totalDistributors * 100).toFixed(0) },
              { label: "Standard Dealers", value: summary.standardCount, color: "#f59e0b", pct: (summary.standardCount / summary.totalDistributors * 100).toFixed(0) },
              { label: "Total Network Size", value: summary.totalDistributors, color: "#60a5fa", pct: "100" },
            ].map((s) => (
              <Card key={s.label} className="p-4 border-border bg-card/60 flex items-center gap-4">
                <div className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0" style={{ background: s.color + "18" }}>
                  <Users className="w-4 h-4" style={{ color: s.color }} />
                </div>
                <div className="min-w-0">
                  <div className="text-[10px] font-mono text-muted-foreground uppercase tracking-wider">{s.label}</div>
                  <div className="text-xl font-mono font-bold text-white">{s.value}</div>
                  <div className="mt-1 h-1 bg-white/10 rounded-full w-full">
                    <div className="h-1 rounded-full" style={{ width: `${s.pct}%`, background: s.color }} />
                  </div>
                </div>
              </Card>
            ))}
          </motion.div>
        )}

        {/* Tier breakdown + Quick Nav */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Tier Health Summary */}
          {tiers && (
            <motion.div initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.6 }}>
              <Card className="p-6 border-border bg-card/80 h-full">
                <h2 className="font-mono text-xs text-muted-foreground uppercase tracking-widest mb-5">Health Score Distribution by Tier</h2>
                <div className="space-y-5">
                  {tiers.map((t) => (
                    <div key={t.tier}>
                      <div className="flex justify-between items-baseline mb-1.5">
                        <span className="text-xs font-mono font-bold" style={{ color: TIER_COLORS[t.tier] }}>{t.tier.toUpperCase()}</span>
                        <span className="text-xs font-mono text-muted-foreground">{t.count} dealers · ₹{t.revenueLocked.toFixed(1)} Cr locked</span>
                      </div>
                      <div className="relative h-5 bg-white/5 rounded overflow-hidden">
                        <motion.div
                          className="absolute left-0 top-0 h-full rounded"
                          style={{ background: TIER_COLORS[t.tier] + "cc" }}
                          initial={{ width: 0 }}
                          animate={{ width: `${t.avgHealthScore}%` }}
                          transition={{ delay: 0.7, duration: 0.8, ease: "easeOut" }}
                        />
                        <div className="absolute inset-0 flex items-center px-2">
                          <span className="text-[10px] font-mono text-white/80 font-bold">{t.avgHealthScore.toFixed(1)} / 100</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            </motion.div>
          )}

          {/* Quick Navigation */}
          <motion.div initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.65 }}>
            <Card className="p-6 border-border bg-card/80 h-full">
              <h2 className="font-mono text-xs text-muted-foreground uppercase tracking-widest mb-5">Quick Access</h2>
              <div className="grid grid-cols-1 gap-3">
                {[
                  { href: "/network", icon: Network, label: "Network Overview", desc: "Territory matrix · Revenue by tier" },
                  { href: "/distributors", icon: Users, label: "Distributor Deep-Dive", desc: "Leaderboard · 12-week trend charts" },
                  { href: "/actions", icon: Target, label: "AI Action Center", desc: `${summary?.restrictedCount ?? 0} accounts · Intervention memos` },
                ].map((n) => (
                  <Link key={n.href} href={n.href}>
                    <div className="flex items-center gap-4 px-4 py-3 rounded border border-border/60 bg-white/2 hover:bg-white/5 hover:border-primary/30 cursor-pointer transition-all group">
                      <div className="w-8 h-8 rounded bg-primary/10 flex items-center justify-center flex-shrink-0 group-hover:bg-primary/20 transition-colors">
                        <n.icon className="w-4 h-4 text-primary" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-sm font-medium text-white">{n.label}</div>
                        <div className="text-[11px] text-muted-foreground font-mono">{n.desc}</div>
                      </div>
                      <Zap className="w-3.5 h-3.5 text-muted-foreground/40 ml-auto flex-shrink-0 group-hover:text-primary/60 transition-colors" />
                    </div>
                  </Link>
                ))}
              </div>
            </Card>
          </motion.div>
        </div>

        {/* Colab Integration Guide */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.75 }}>
          <Card className="p-6 border-border bg-card/60">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Terminal className="w-4 h-4 text-muted-foreground" />
                <h3 className="font-mono text-xs text-muted-foreground uppercase tracking-widest">Colab Integration — Push Model Results to This Dashboard</h3>
              </div>
              <CopyButton text={EXAMPLE_PAYLOAD} />
            </div>
            <div className="bg-black/60 rounded border border-border/50 p-4 font-mono text-xs text-muted-foreground overflow-x-auto leading-relaxed max-h-48 overflow-y-auto">
              <pre className="whitespace-pre">{EXAMPLE_PAYLOAD}</pre>
            </div>
          </Card>
        </motion.div>
      </div>
    </Layout>
  );
}
