import React, { useState } from "react";
import { Layout } from "@/components/Layout";
import {
  useListTerritories,
  useGetTierBreakdown,
  getListTerritoriesQueryKey,
  getGetTierBreakdownQueryKey,
} from "@workspace/api-client-react";
import {
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  Cell,
  Legend,
} from "recharts";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

const TIER_COLORS: Record<string, string> = {
  Priority: "#10b981",
  Standard: "#f59e0b",
  Restricted: "#E8001D",
};

const CustomScatterTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    const d = payload[0].payload;
    return (
      <div className="bg-card border border-border rounded p-3 text-xs font-mono shadow-xl">
        <p className="text-white font-bold mb-1">{d.district}, {d.state}</p>
        <p className="text-muted-foreground">Health Score: <span className="text-white">{d.healthScore}</span></p>
        <p className="text-muted-foreground">Market Potential: <span className="text-white">{d.marketPotential}</span></p>
        <p className="text-muted-foreground">Revenue Locked: <span className="text-white">₹{d.revenueLocked.toFixed(2)} Cr</span></p>
        <p className="text-muted-foreground">Distributors: <span className="text-white">{d.distributorCount}</span></p>
        <span
          className="mt-2 inline-block px-2 py-0.5 rounded text-[10px] font-bold"
          style={{ background: TIER_COLORS[d.tier] + "33", color: TIER_COLORS[d.tier], border: `1px solid ${TIER_COLORS[d.tier]}44` }}
        >
          {d.tier}
        </span>
      </div>
    );
  }
  return null;
};

const CustomBarTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-card border border-border rounded p-3 text-xs font-mono shadow-xl">
        <p className="font-bold mb-1" style={{ color: TIER_COLORS[label] || "#fff" }}>{label}</p>
        <p className="text-muted-foreground">Revenue Locked: <span className="text-white">₹{Number(payload[0]?.value).toFixed(2)} Cr</span></p>
        <p className="text-muted-foreground">Distributors: <span className="text-white">{payload[1]?.value}</span></p>
        <p className="text-muted-foreground">Avg Health: <span className="text-white">{Number(payload[2]?.value).toFixed(1)}</span></p>
      </div>
    );
  }
  return null;
};

export default function NetworkOverview() {
  const [hoveredTier, setHoveredTier] = useState<string | null>(null);

  const { data: territories, isLoading: isTerrLoading } = useListTerritories({
    query: { queryKey: getListTerritoriesQueryKey() },
  });

  const { data: tierBreakdown, isLoading: isTierLoading } = useGetTierBreakdown({
    query: { queryKey: getGetTierBreakdownQueryKey() },
  });

  return (
    <Layout>
      <div className="p-8 max-w-[1600px] mx-auto">
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
          <h1 className="text-3xl font-bold tracking-tight mb-1">NETWORK OVERVIEW</h1>
          <p className="text-muted-foreground text-sm mb-8">Territory Opportunity Matrix & Revenue Distribution by Tier</p>
        </motion.div>

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 mb-6">
          {/* Scatter Plot */}
          <motion.div
            className="xl:col-span-2"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <Card className="p-6 border-border bg-card/80 h-full">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="font-mono text-xs text-muted-foreground uppercase tracking-widest mb-1">Territory Opportunity Matrix</h2>
                  <p className="text-sm text-white font-medium">Market Potential vs. Health Score</p>
                </div>
                <div className="flex gap-3">
                  {Object.entries(TIER_COLORS).map(([tier, color]) => (
                    <button
                      key={tier}
                      onMouseEnter={() => setHoveredTier(tier)}
                      onMouseLeave={() => setHoveredTier(null)}
                      className="flex items-center gap-1.5 text-xs font-mono transition-opacity"
                      style={{ opacity: hoveredTier && hoveredTier !== tier ? 0.3 : 1 }}
                    >
                      <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background: color }} />
                      <span className="text-muted-foreground">{tier}</span>
                    </button>
                  ))}
                </div>
              </div>

              {isTerrLoading ? (
                <Skeleton className="h-72 w-full" />
              ) : (
                <ResponsiveContainer width="100%" height={320}>
                  <ScatterChart margin={{ top: 10, right: 20, bottom: 20, left: 10 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                    <XAxis
                      dataKey="marketPotential"
                      type="number"
                      name="Market Potential"
                      domain={[0, 100]}
                      label={{ value: "Market Potential →", position: "insideBottom", offset: -10, style: { fill: "#666", fontSize: 10, fontFamily: "monospace" } }}
                      tick={{ fill: "#666", fontSize: 10, fontFamily: "monospace" }}
                    />
                    <YAxis
                      dataKey="healthScore"
                      type="number"
                      name="Health Score"
                      domain={[0, 100]}
                      label={{ value: "Health Score →", angle: -90, position: "insideLeft", offset: 15, style: { fill: "#666", fontSize: 10, fontFamily: "monospace" } }}
                      tick={{ fill: "#666", fontSize: 10, fontFamily: "monospace" }}
                    />
                    <Tooltip content={<CustomScatterTooltip />} />
                    {["Priority", "Standard", "Restricted"].map((tier) => (
                      <Scatter
                        key={tier}
                        name={tier}
                        data={(territories || []).filter((t) => t.tier === tier)}
                        fill={TIER_COLORS[tier]}
                        opacity={hoveredTier && hoveredTier !== tier ? 0.1 : 0.85}
                      />
                    ))}
                  </ScatterChart>
                </ResponsiveContainer>
              )}

              {/* Quadrant Labels */}
              <div className="mt-2 grid grid-cols-2 gap-2 text-[10px] font-mono text-muted-foreground/50">
                <div className="text-center">LOW POTENTIAL · LOW HEALTH → Disengage</div>
                <div className="text-center">HIGH POTENTIAL · LOW HEALTH → Priority Intervention</div>
              </div>
            </Card>
          </motion.div>

          {/* Tier Breakdown Stats */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <Card className="p-6 border-border bg-card/80 h-full">
              <h2 className="font-mono text-xs text-muted-foreground uppercase tracking-widest mb-6">Tier Breakdown</h2>
              {isTierLoading ? (
                <div className="space-y-4">
                  {[1, 2, 3].map((i) => <Skeleton key={i} className="h-20 w-full" />)}
                </div>
              ) : (
                <div className="space-y-4">
                  {(tierBreakdown || []).map((t) => (
                    <div key={t.tier} className="rounded border p-4" style={{ borderColor: TIER_COLORS[t.tier] + "30", background: TIER_COLORS[t.tier] + "08" }}>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-xs font-mono font-bold" style={{ color: TIER_COLORS[t.tier] }}>{t.tier.toUpperCase()}</span>
                        <span className="text-xs font-mono text-muted-foreground">{t.count} dealers</span>
                      </div>
                      <div className="text-2xl font-bold font-mono text-white">₹{t.revenueLocked.toFixed(1)} <span className="text-sm text-muted-foreground">Cr</span></div>
                      <div className="mt-2 flex items-center gap-2">
                        <div className="flex-1 h-1.5 bg-white/10 rounded-full overflow-hidden">
                          <div className="h-full rounded-full" style={{ width: `${t.avgHealthScore}%`, background: TIER_COLORS[t.tier] }} />
                        </div>
                        <span className="text-xs font-mono text-muted-foreground">{t.avgHealthScore.toFixed(0)}/100</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </Card>
          </motion.div>
        </div>

        {/* Revenue Locked Bar Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
        >
          <Card className="p-6 border-border bg-card/80">
            <div className="mb-6">
              <h2 className="font-mono text-xs text-muted-foreground uppercase tracking-widest mb-1">Revenue Locked by Tier</h2>
              <p className="text-sm text-white font-medium">Comparative revenue lock-in across distributor tiers</p>
            </div>
            {isTierLoading ? (
              <Skeleton className="h-48 w-full" />
            ) : (
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={tierBreakdown || []} margin={{ top: 5, right: 20, left: 10, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
                  <XAxis dataKey="tier" tick={{ fill: "#888", fontSize: 11, fontFamily: "monospace" }} />
                  <YAxis tick={{ fill: "#888", fontSize: 10, fontFamily: "monospace" }} tickFormatter={(v) => `₹${v}`} />
                  <Tooltip content={<CustomBarTooltip />} />
                  <Bar dataKey="revenueLocked" name="Revenue Locked (Cr)" radius={[3, 3, 0, 0]}>
                    {(tierBreakdown || []).map((entry) => (
                      <Cell key={entry.tier} fill={TIER_COLORS[entry.tier]} fillOpacity={0.8} />
                    ))}
                  </Bar>
                  <Bar dataKey="count" name="Distributor Count" radius={[3, 3, 0, 0]} fill="#ffffff" fillOpacity={0.1} />
                  <Bar dataKey="avgHealthScore" name="Avg Health Score" radius={[3, 3, 0, 0]} fill="#60a5fa" fillOpacity={0.5} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </Card>
        </motion.div>
      </div>
    </Layout>
  );
}
