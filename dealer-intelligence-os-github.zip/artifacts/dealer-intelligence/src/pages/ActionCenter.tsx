import React, { useState } from "react";
import { Layout } from "@/components/Layout";
import {
  useListDistributors,
  useGetDistributorMemo,
  getListDistributorsQueryKey,
  getGetDistributorMemoQueryKey,
} from "@workspace/api-client-react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { AlertTriangle, CheckCircle, ChevronRight, Zap, Target, TrendingDown } from "lucide-react";

const URGENCY_CONFIG: Record<string, { color: string; bg: string; icon: React.ElementType }> = {
  High: { color: "#E8001D", bg: "#E8001D18", icon: AlertTriangle },
  Medium: { color: "#f59e0b", bg: "#f59e0b18", icon: Zap },
  Low: { color: "#60a5fa", bg: "#60a5fa18", icon: Target },
};

function MemoPanel({ distributorId }: { distributorId: number }) {
  const { data: memo, isLoading } = useGetDistributorMemo(distributorId, {
    query: { queryKey: getGetDistributorMemoQueryKey(distributorId), enabled: !!distributorId },
  });

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-6 w-48" />
        <Skeleton className="h-24 w-full" />
        <Skeleton className="h-32 w-full" />
      </div>
    );
  }

  if (!memo) return null;

  const urg = URGENCY_CONFIG[memo.urgency] || URGENCY_CONFIG.Low;
  const UrgIcon = urg.icon;

  return (
    <motion.div
      key={distributorId}
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      transition={{ duration: 0.3 }}
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-5">
        <div>
          <h3 className="text-lg font-bold text-white">{memo.distributorName}</h3>
          <div className="flex items-center gap-3 mt-1">
            <span
              className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-mono font-bold"
              style={{ background: urg.bg, color: urg.color, border: `1px solid ${urg.color}44` }}
            >
              <UrgIcon className="w-3 h-3" />
              {memo.urgency.toUpperCase()} URGENCY
            </span>
            <span className="text-xs font-mono text-emerald-400">
              Est. Recovery: ₹{memo.estimatedRecovery.toFixed(2)} Cr/wk
            </span>
          </div>
        </div>
      </div>

      {/* Memo Text */}
      <div className="bg-white/3 border border-border/60 rounded p-4 mb-5">
        <div className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest mb-2">EXECUTIVE MEMO</div>
        <p className="text-sm text-muted-foreground leading-relaxed">{memo.memo}</p>
      </div>

      {/* Two Columns */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Key Issues */}
        <div className="bg-red-950/20 border border-red-500/20 rounded p-4">
          <div className="flex items-center gap-2 mb-3">
            <TrendingDown className="w-3.5 h-3.5 text-red-400" />
            <span className="text-[10px] font-mono text-red-400 uppercase tracking-widest">Key Issues Identified</span>
          </div>
          <ul className="space-y-2">
            {memo.keyIssues.map((issue, i) => (
              <li key={i} className="flex gap-2 text-xs text-muted-foreground">
                <span className="text-red-400 font-mono mt-0.5 flex-shrink-0">→</span>
                <span>{issue}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Actions */}
        <div className="bg-emerald-950/20 border border-emerald-500/20 rounded p-4">
          <div className="flex items-center gap-2 mb-3">
            <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
            <span className="text-[10px] font-mono text-emerald-400 uppercase tracking-widest">Recommended Actions</span>
          </div>
          <ul className="space-y-2">
            {memo.recommendedActions.map((action, i) => (
              <li key={i} className="flex gap-2 text-xs text-muted-foreground">
                <span className="text-emerald-400 font-mono mt-0.5 font-bold flex-shrink-0">{i + 1}.</span>
                <span>{action}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </motion.div>
  );
}

export default function ActionCenter() {
  const [selectedId, setSelectedId] = useState<number | null>(null);

  const { data: restricted, isLoading } = useListDistributors(
    { tier: "Restricted" },
    { query: { queryKey: getListDistributorsQueryKey({ tier: "Restricted" }) } }
  );

  const sortedRestricted = [...(restricted || [])].sort((a, b) => a.healthScore - b.healthScore);

  return (
    <Layout>
      <div className="p-8 max-w-[1600px] mx-auto">
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
          <h1 className="text-3xl font-bold tracking-tight mb-1">AI ACTION CENTER</h1>
          <p className="text-muted-foreground text-sm mb-6">
            Intervention memos for restricted distributors — select an account to view
          </p>
        </motion.div>

        {/* Alert Banner */}
        {!isLoading && sortedRestricted.length > 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="mb-6 flex items-center gap-3 px-4 py-3 rounded border border-red-500/30 bg-red-500/8"
          >
            <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0" />
            <p className="text-sm text-red-300/80">
              <span className="font-bold text-red-400">{sortedRestricted.length} RESTRICTED ACCOUNTS</span>
              {" "}require immediate intervention. Combined recovery potential:{" "}
              <span className="font-bold text-emerald-400">
                ₹{sortedRestricted.reduce((acc, d) => acc + d.recoverableRevenue, 0).toFixed(2)} Cr/week
              </span>
            </p>
          </motion.div>
        )}

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
          {/* Distributor List */}
          <div className="xl:col-span-1">
            <Card className="border-border bg-card/80 overflow-hidden">
              <div className="px-4 py-3 border-b border-border bg-white/3">
                <span className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest">
                  Restricted Accounts ({sortedRestricted.length})
                </span>
              </div>
              <div className="divide-y divide-border/40 max-h-[70vh] overflow-y-auto">
                {isLoading ? (
                  Array.from({ length: 6 }).map((_, i) => (
                    <div key={i} className="px-4 py-4">
                      <Skeleton className="h-4 w-3/4 mb-2" />
                      <Skeleton className="h-3 w-1/2" />
                    </div>
                  ))
                ) : sortedRestricted.length === 0 ? (
                  <div className="py-12 text-center text-muted-foreground font-mono text-xs">
                    NO RESTRICTED ACCOUNTS
                  </div>
                ) : (
                  sortedRestricted.map((d, i) => {
                    const urgency = d.healthScore < 30 ? "High" : d.healthScore < 50 ? "Medium" : "Low";
                    const urg = URGENCY_CONFIG[urgency];
                    return (
                      <motion.button
                        key={d.id}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: Math.min(i * 0.02, 0.4) }}
                        onClick={() => setSelectedId(selectedId === d.id ? null : d.id)}
                        className={`w-full text-left px-4 py-4 transition-colors group flex items-center gap-3 ${
                          selectedId === d.id ? "bg-white/5 border-l-2" : "hover:bg-white/3 border-l-2 border-l-transparent"
                        }`}
                        style={{ borderLeftColor: selectedId === d.id ? urg.color : "transparent" }}
                      >
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-xs font-medium text-white truncate">{d.name}</span>
                            <span
                              className="text-[9px] font-mono font-bold px-1.5 py-0.5 rounded flex-shrink-0 ml-2"
                              style={{ background: urg.bg, color: urg.color }}
                            >
                              {urgency.toUpperCase()}
                            </span>
                          </div>
                          <div className="text-[10px] text-muted-foreground font-mono">{d.district}, {d.state}</div>
                          <div className="flex items-center gap-3 mt-1.5">
                            <div className="flex items-center gap-1">
                              <div className="w-12 h-1 bg-white/10 rounded-full overflow-hidden">
                                <div className="h-full rounded-full bg-red-500" style={{ width: `${d.healthScore}%` }} />
                              </div>
                              <span className="text-[10px] font-mono text-red-400">{d.healthScore.toFixed(0)}</span>
                            </div>
                            <span className="text-[10px] font-mono text-emerald-400">+₹{d.recoverableRevenue.toFixed(1)} Cr</span>
                          </div>
                        </div>
                        <ChevronRight className={`w-4 h-4 text-muted-foreground/40 transition-transform group-hover:translate-x-0.5 ${selectedId === d.id ? "text-white/60" : ""}`} />
                      </motion.button>
                    );
                  })
                )}
              </div>
            </Card>
          </div>

          {/* Memo Panel */}
          <div className="xl:col-span-2">
            <Card className="border-border bg-card/80 p-6 min-h-[400px]">
              <AnimatePresence mode="wait">
                {selectedId ? (
                  <MemoPanel key={selectedId} distributorId={selectedId} />
                ) : (
                  <motion.div
                    key="empty"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="flex flex-col items-center justify-center h-64 text-center"
                  >
                    <div className="w-16 h-16 rounded-full bg-white/3 border border-border flex items-center justify-center mb-4">
                      <Target className="w-8 h-8 text-muted-foreground/40" />
                    </div>
                    <p className="font-mono text-xs text-muted-foreground uppercase tracking-widest">SELECT AN ACCOUNT</p>
                    <p className="font-mono text-[10px] text-muted-foreground/50 mt-1">to view AI-generated action memo</p>
                  </motion.div>
                )}
              </AnimatePresence>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
}
