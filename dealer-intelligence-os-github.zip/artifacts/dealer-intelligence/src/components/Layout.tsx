import React from "react";
import { Link, useLocation } from "wouter";
import { useRunSimulation, getRunSimulationUrl } from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Activity, Map, Users, AlertCircle, Play } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useQueryClient } from "@tanstack/react-query";

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const [location] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const runSimulation = useRunSimulation({
    mutation: {
      onSuccess: (data) => {
        toast({
          title: "Simulation Complete",
          description: data.message || `Generated ${data.distributorsGenerated} distributors.`,
        });
        queryClient.invalidateQueries();
      },
      onError: (err) => {
        toast({
          title: "Simulation Failed",
          description: err instanceof Error ? err.message : "Failed to run simulation",
          variant: "destructive",
        });
      },
    },
  });

  const handleSimulate = () => {
    runSimulation.mutate();
  };

  const navItems = [
    { href: "/", label: "Command Center", icon: Activity },
    { href: "/network", label: "Network", icon: Map },
    { href: "/distributors", label: "Distributors", icon: Users },
    { href: "/actions", label: "Action Center", icon: AlertCircle },
  ];

  return (
    <div className="flex h-screen w-full overflow-hidden bg-background text-foreground dark">
      {/* Sidebar */}
      <div className="w-64 border-r border-border bg-sidebar flex flex-col flex-shrink-0">
        <div className="p-6">
          <div className="flex items-center gap-2">
            <div className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest mt-1 border border-border px-1.5 py-0.5 rounded">OS</div>
          </div>
        </div>

        <ScrollArea className="flex-1 px-4">
          <nav className="space-y-1">
            {navItems.map((item) => {
              const isActive = location === item.href;
              const Icon = item.icon;
              return (
                <Link key={item.href} href={item.href}>
                  <div
                    className={`flex items-center gap-3 px-3 py-2.5 rounded-md cursor-pointer transition-colors text-sm font-medium ${
                      isActive
                        ? "bg-primary/10 text-primary border border-primary/20"
                        : "text-muted-foreground hover:text-foreground hover:bg-white/5 border border-transparent"
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    {item.label}
                  </div>
                </Link>
              );
            })}
          </nav>
        </ScrollArea>

        <div className="p-4 mt-auto border-t border-border">
          <Button
            onClick={handleSimulate}
            disabled={runSimulation.isPending}
            className="w-full bg-primary/20 text-primary hover:bg-primary/30 border border-primary/30 font-mono text-xs shadow-none"
            variant="outline"
          >
            {runSimulation.isPending ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Play className="w-4 h-4 mr-2" />
            )}
            RUN SIMULATION
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 overflow-auto relative">
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] opacity-[0.03] pointer-events-none mix-blend-overlay"></div>
        {children}
      </main>
    </div>
  );
}
