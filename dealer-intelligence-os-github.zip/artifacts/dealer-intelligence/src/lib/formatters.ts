import { format } from "date-fns";

export function formatCurrency(value: number | undefined | null): string {
  if (value === undefined || value === null) return "₹0.00 Cr";
  return `₹${value.toFixed(2)} Cr`;
}

export function formatPercentage(value: number | undefined | null): string {
  if (value === undefined || value === null) return "0.00%";
  return `${value.toFixed(2)}%`;
}

export function formatDate(dateString: string | undefined | null): string {
  if (!dateString) return "N/A";
  try {
    return format(new Date(dateString), "MMM d, yyyy HH:mm");
  } catch (e) {
    return dateString;
  }
}

export function getHealthColor(score: number): string {
  if (score <= 40) return "bg-red-500";
  if (score <= 70) return "bg-amber-500";
  return "bg-green-500";
}

export function getTierColor(tier: string): string {
  if (tier === "Priority") return "bg-emerald-500/10 text-emerald-500 border-emerald-500/20";
  if (tier === "Standard") return "bg-amber-500/10 text-amber-500 border-amber-500/20";
  if (tier === "Restricted") return "bg-red-500/10 text-red-500 border-red-500/20";
  return "bg-gray-500/10 text-gray-500 border-gray-500/20";
}
