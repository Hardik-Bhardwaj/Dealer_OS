import { pgTable, serial, text, real, integer, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const tierEnum = pgEnum("tier", ["Priority", "Standard", "Restricted"]);
export const urgencyEnum = pgEnum("urgency", ["High", "Medium", "Low"]);

export const distributorsTable = pgTable("distributors", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  state: text("state").notNull(),
  district: text("district").notNull(),
  tier: tierEnum("tier").notNull(),
  healthScore: real("health_score").notNull(),
  sellThrough: real("sell_through").notNull(),
  inventoryAge: real("inventory_age").notNull(),
  paymentDelay: real("payment_delay").notNull(),
  returnRate: real("return_rate").notNull(),
  dealerCoverage: real("dealer_coverage").notNull(),
  revenueLocked: real("revenue_locked").notNull(),
  recoverableRevenue: real("recoverable_revenue").notNull(),
  marketPotential: real("market_potential").notNull(),
  weeklyRevenue: real("weekly_revenue").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const weeklyTrendsTable = pgTable("weekly_trends", {
  id: serial("id").primaryKey(),
  distributorId: integer("distributor_id").notNull(),
  week: text("week").notNull(),
  score: real("score").notNull(),
});

export const actionMemosTable = pgTable("action_memos", {
  id: serial("id").primaryKey(),
  distributorId: integer("distributor_id").notNull().unique(),
  memo: text("memo").notNull(),
  keyIssues: text("key_issues").notNull(),
  recommendedActions: text("recommended_actions").notNull(),
  estimatedRecovery: real("estimated_recovery").notNull(),
  urgency: urgencyEnum("urgency").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insightsSnapshotTable = pgTable("insights_snapshot", {
  id: serial("id").primaryKey(),
  totalRevenueLocked: real("total_revenue_locked").notNull(),
  restrictedCount: integer("restricted_count").notNull(),
  avgHealthScore: real("avg_health_score").notNull(),
  recoverableWeeklyRevenue: real("recoverable_weekly_revenue").notNull(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertDistributorSchema = createInsertSchema(distributorsTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertDistributor = z.infer<typeof insertDistributorSchema>;
export type Distributor = typeof distributorsTable.$inferSelect;
